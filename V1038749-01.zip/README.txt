Dear MySQL users,

MySQL Enterprise Backup 8.0.35, a new version of the online MySQL backup
tool, has been released. Moving forward, the 8.0 series will contain security
and bug fixes only. For new features please refer to the MySQL Enterprise
Backup 8.2.0 Innovation release.

MySQL Enterprise Backup 8.0.35 is now available for download from the My
Oracle Support (MOS) website as our latest GA release. This release will be
available on eDelivery (OSDC) after the next upload cycle. MySQL Enterprise
Backup is a commercial extension to the MySQL family of products.

MySQL Enterprise Backup 8.0.35 is the latest bugfix release for MySQL
Enterprise Backup. It only supports MySQL Server 8.0.35. For earlier
versions of MySQL 8.0, use the MySQL Enterprise Backup version with
the same version number as the server. For MySQL Server 8.2.0,
please use MySQL Enterprise Backup 8.2.0. For MySQL Server 5.7,
please use MySQL Enterprise Backup 4.1.

A brief summary of the changes in MySQL Enterprise Backup (MEB)
since the previous version is given below.

Changes in MySQL Enterprise Backup 8.0.35 (2023-10-25, Bugfix
Release)

Functionality Added or Changed

     * Important Change: For platforms on which OpenSSL
       libraries are bundled, the linked OpenSSL library for
       MySQL Enterprise Backup has been updated to version
       3.0.10. Issues fixed in OpenSSL version 3.0.10 are
       described at https://www.openssl.org/news/cl30.txt. 
       (Bug #35732474)

     * Binary packages that include curl rather than linking to
       the system curl library have been upgraded to use curl
       8.4.0. (Bug #35897778)

On Behalf of the MySQL Engineering Team,
Nawaz Nazeer Ahamed
